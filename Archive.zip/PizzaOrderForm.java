import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class PizzaOrderForm {
   private JFrame frame;
   private List<JPanel> selectedPizzas = new ArrayList<>();
   private List<JPanel> selectedAddons = new ArrayList<>();
   private String[] pizzaNames = { "Margherita", "Pepperoni", "Veggie", "BBQ Chicken" };
   private int[] pizzaPrices = { 850, 950, 800, 1000 };
   private String[] addonNames = { "Extra Cheese", "Cold Drink", "Garlic Bread", "Dipping Sauce" };
   private int[] addonPrices = { 100, 80, 120, 50 };

   public PizzaOrderForm() {
      frame = new JFrame("Pizza Order Form");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(1000, 800);
      frame.setLocationRelativeTo(null);
      frame.getContentPane().setBackground(Color.WHITE);

      JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
      mainPanel.setBackground(Color.WHITE);
      mainPanel.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
      frame.add(mainPanel);

      JPanel pizzaPanel = createPizzaPanel();
      JPanel addonsPanel = createAddonsPanel();
      JPanel buttonPanel = createOrderButtonPanel();

      mainPanel.add(pizzaPanel, BorderLayout.NORTH);
      mainPanel.add(addonsPanel, BorderLayout.CENTER);
      mainPanel.add(buttonPanel, BorderLayout.SOUTH);
   }

   private JPanel createOrderButtonPanel() {
      JButton orderButton = new JButton("PLACE ORDER") {
         @Override
         protected void paintComponent(Graphics g) {
            if (getModel().isPressed()) {
               g.setColor(new Color(0x9B144A));
            } else {
               g.setColor(new Color(0xBE185D));
            }
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            super.paintComponent(g);
         }
      };
      orderButton.setContentAreaFilled(false);
      orderButton.setFocusPainted(false);
      orderButton.setForeground(Color.WHITE);
      orderButton.setFont(new Font("Segoe UI", Font.PLAIN, 16));
      orderButton.addActionListener(e -> printOrder());
      orderButton.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));
      Dimension fixed = new Dimension(200, 50);
      orderButton.setMaximumSize(fixed);
      orderButton.setPreferredSize(fixed);
      orderButton.setMinimumSize(fixed);
      orderButton.setAlignmentX(Component.CENTER_ALIGNMENT);

      JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
      buttonPanel.setBackground(Color.WHITE);
      buttonPanel.add(orderButton);
      return buttonPanel;
   }

   private void printOrder() {
      if (selectedPizzas.isEmpty()) {
         JOptionPane.showMessageDialog(frame, "Please select at least one pizza!", "Error",
               JOptionPane.ERROR_MESSAGE);
         return;
      }

      System.out.println("Order Summary:");
      System.out.println("Pizzas:");
      for (JPanel pizza : selectedPizzas) {
         int index = getComponentIndex(pizza.getParent(), pizza);
         System.out.println("- " + pizzaNames[index] + ": " + pizzaPrices[index] + " Tk");
      }

      if (!selectedAddons.isEmpty()) {
         System.out.println("\nAdd-ons:");
         for (JPanel addon : selectedAddons) {
            int index = getComponentIndex(addon.getParent(), addon);
            System.out.println("- " + addonNames[index] + ": +" + addonPrices[index] + " Tk");
         }
      }

      int total = calculateTotal();
      System.out.println("\nTotal: " + total + " Tk");
   }

   private int calculateTotal() {
      int total = 0;
      for (JPanel pizza : selectedPizzas) {
         int index = getComponentIndex(pizza.getParent(), pizza);
         total += pizzaPrices[index];
      }
      for (JPanel addon : selectedAddons) {
         int index = getComponentIndex(addon.getParent(), addon);
         total += addonPrices[index];
      }
      return total;
   }

   private JPanel createPizzaPanel() {
      JPanel pizzaPanel = new JPanel();
      pizzaPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
      pizzaPanel.setBackground(Color.WHITE);

      String[] pizzaImages = { "images/2.jpg", "images/1.jpg", "images/3.jpg", "images/4.jpg" };

      for (int i = 0; i < pizzaNames.length; i++) {
         JPanel cardPanel = new JPanel();
         cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
         cardPanel.setBackground(Color.WHITE);
         cardPanel.setPreferredSize(new Dimension(200, 250));
         cardPanel.setBorder(BorderFactory.createCompoundBorder(
               BorderFactory.createLineBorder(new Color(0xE2E8F0), 2),
               BorderFactory.createEmptyBorder(18, 18, 18, 18)));

         ImageIcon icon = new ImageIcon(pizzaImages[i]);
         Image image = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
         JLabel imageLabel = new JLabel(new ImageIcon(image));
         imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

         JLabel nameLabel = new JLabel(pizzaNames[i]);
         nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
         nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

         JLabel priceLabel = new JLabel(pizzaPrices[i] + " Tk");
         priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
         priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

         cardPanel.addMouseListener(new MouseAdapter() {
            private boolean selected = false;

            @Override
            public void mousePressed(MouseEvent e) {
               selected = !selected;
               if (selected) {
                  selectedPizzas.add(cardPanel);
               } else {
                  selectedPizzas.remove(cardPanel);
               }
               cardPanel.setBorder(BorderFactory.createCompoundBorder(
                     BorderFactory.createLineBorder(selected ? new Color(0xBE185D) : new Color(0xE2E8F0), 2),
                     BorderFactory.createEmptyBorder(18, 18, 18, 18)));
            }
         });

         cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
         cardPanel.add(imageLabel);
         cardPanel.add(Box.createRigidArea(new Dimension(0, 10)));
         cardPanel.add(nameLabel);
         cardPanel.add(priceLabel);
         pizzaPanel.add(cardPanel);
      }
      return pizzaPanel;
   }

   private JPanel createAddonsPanel() {
      JPanel addonsPanel = new JPanel();
      addonsPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 20));
      addonsPanel.setBackground(Color.WHITE);

      for (int i = 0; i < addonNames.length; i++) {
         JPanel cardPanel = new JPanel();
         cardPanel.setLayout(new BoxLayout(cardPanel, BoxLayout.Y_AXIS));
         cardPanel.setBackground(Color.WHITE);
         cardPanel.setBorder(BorderFactory.createCompoundBorder(
               BorderFactory.createLineBorder(new Color(0xE2E8F0), 2),
               BorderFactory.createEmptyBorder(24, 32, 24, 32)));

         JLabel nameLabel = new JLabel(addonNames[i]);
         nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
         nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

         JLabel priceLabel = new JLabel("+" + addonPrices[i] + " Tk");
         priceLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
         priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

         cardPanel.addMouseListener(new MouseAdapter() {
            private boolean selected = false;

            @Override
            public void mousePressed(MouseEvent e) {
               selected = !selected;
               if (selected) {
                  selectedAddons.add(cardPanel);
               } else {
                  selectedAddons.remove(cardPanel);
               }
               cardPanel.setBorder(BorderFactory.createCompoundBorder(
                     BorderFactory.createLineBorder(selected ? new Color(0xBE185D) : new Color(0xE2E8F0), 2),
                     BorderFactory.createEmptyBorder(24, 32, 24, 32)));
            }
         });

         cardPanel.add(nameLabel);
         cardPanel.add(Box.createRigidArea(new Dimension(0, 5)));
         cardPanel.add(priceLabel);
         addonsPanel.add(cardPanel);
      }
      return addonsPanel;
   }

   private int getComponentIndex(Container parent, Component child) {
      for (int i = 0; i < parent.getComponentCount(); i++) {
         if (parent.getComponent(i) == child) {
            return i;
         }
      }
      return -1;
   }

   public void show() {
      frame.setVisible(true);
   }

   public static void main(String[] args) {
      SwingUtilities.invokeLater(() -> {
         new PizzaOrderForm().show();
      });
   }
}